from tkinter import *
from tkinter.filedialog import askopenfilename
import tkinter as tk
from PIL import Image, ImageTk
import sqlite_execute
import coordinate_crud
from tkinter import messagebox as mb


def event2canvas(e, c): return (c.canvasx(e.x), c.canvasy(e.y))


if __name__ == "__main__":

    root = Tk()

    lat = 0
    lon = 0

    # setting up a tkinter canvas with scrollbars
    frame = Frame(root, bd=2, relief=SUNKEN)
    frame.grid_rowconfigure(0, weight=2)
    frame.grid_columnconfigure(0, weight=2)
    xscroll = Scrollbar(frame, orient=HORIZONTAL)
    xscroll.grid(row=1, column=0, sticky=E+W)
    yscroll = Scrollbar(frame)
    yscroll.grid(row=0, column=1, sticky=N+S)
    canvas = Canvas(frame, bd=0, xscrollcommand=xscroll.set,
                    yscrollcommand=yscroll.set)
    canvas.grid(row=0, column=0, sticky=N+S+E+W)
    xscroll.config(command=canvas.xview)
    yscroll.config(command=canvas.yview)
    frame.pack(fill=BOTH, expand=1)

    # adding the image
    # File = askopenfilename(parent=root, initialdir="M:/",
    #                        title='Choose an image.')
    # print("opening %s" % File)

    # img = PhotoImage(file=File)

    File = 'map.jpg'

    img = ImageTk.PhotoImage(Image.open(File))  # PIL solution

    canvas.create_image(0, 0, image=img, anchor="nw")
    canvas.config(scrollregion=canvas.bbox(ALL))

    def printcoords(event):
        # outputting x and y coords to console
        cx, cy = event2canvas(event, canvas)

        # set value to global v...
        global lat
        global lon
        lat = cy
        lon = cx
        print("(%d, %d) / (%d, %d)" % (event.x, event.y, cx, cy))

    # mouseclick event
    canvas.bind("<ButtonPress-1>", printcoords)
    # canvas.bind("<ButtonRelease-1>", printcoords)

    # tk.Button(master, text='Add', command=master.quit).grid(
    #     row=3, column=0, sticky=tk.W, pady=4)
    # tk.Button(master, text='Delete', command=show_entry_fields).grid(
    #     row=3, column=1, sticky=tk.W, pady=4)

    # tk.mainloop()

    def handleAddButton():
        global lat
        global lon
        print(lat)
        print(lon)
        coordinate_crud.add(
            str(lat), str(lon))

    tk.Button(root, text="Add", command=handleAddButton).pack()
    tk.Button(root, text="Delete").pack()

    root.mainloop()
